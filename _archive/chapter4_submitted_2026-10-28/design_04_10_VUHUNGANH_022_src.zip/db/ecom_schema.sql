-- E-commerce database generated from the Chapter 4.2 data model (tools/model.py).
-- Target: PostgreSQL. Inheritance uses one table per class: a sub-table shares the
-- primary key of its parent table and references it (class table inheritance).

DROP TABLE IF EXISTS pay_credit;
DROP TABLE IF EXISTS pay_cash;
DROP TABLE IF EXISTS payment;
DROP TABLE IF EXISTS shipping;
DROP TABLE IF EXISTS order_item;
DROP TABLE IF EXISTS orders;
DROP TABLE IF EXISTS cart_item;
DROP TABLE IF EXISTS cart;
DROP TABLE IF EXISTS product_feature;
DROP TABLE IF EXISTS mobile;
DROP TABLE IF EXISTS laptop;
DROP TABLE IF EXISTS electronics;
DROP TABLE IF EXISTS shoes;
DROP TABLE IF EXISTS clothes;
DROP TABLE IF EXISTS book;
DROP TABLE IF EXISTS product;
DROP TABLE IF EXISTS address;
DROP TABLE IF EXISTS customer_new;
DROP TABLE IF EXISTS customer_vip;
DROP TABLE IF EXISTS customer;

-- Customer + FullName
CREATE TABLE customer (
    customer_id   varchar(20)  NOT NULL PRIMARY KEY,
    first_name    varchar(50)  NOT NULL,
    middle_name   varchar(50),
    last_name     varchar(50)  NOT NULL,
    email         varchar(120) NOT NULL UNIQUE,
    phone         varchar(20),
    date_of_birth date
);

-- CustomerVIP
CREATE TABLE customer_vip (
    customer_id   varchar(20)  NOT NULL PRIMARY KEY REFERENCES customer (customer_id) ON DELETE CASCADE,
    vip_level     integer      NOT NULL CHECK (vip_level >= 1),
    discount_rate numeric(4,3) NOT NULL CHECK (discount_rate >= 0 AND discount_rate < 1),
    reward_points integer      NOT NULL CHECK (reward_points >= 0)
);

-- CustomerNew
CREATE TABLE customer_new (
    customer_id     varchar(20) NOT NULL PRIMARY KEY REFERENCES customer (customer_id) ON DELETE CASCADE,
    registered_date date        NOT NULL,
    welcome_voucher varchar(30)
);

-- Address
CREATE TABLE address (
    address_id   varchar(20)  NOT NULL PRIMARY KEY,
    customer_id  varchar(20)  NOT NULL REFERENCES customer (customer_id),
    house_number varchar(20)  NOT NULL,
    street       varchar(100) NOT NULL,
    district     varchar(60)  NOT NULL,
    city         varchar(60)  NOT NULL
);

-- Product
CREATE TABLE product (
    product_id     varchar(20)   NOT NULL PRIMARY KEY,
    product_type   varchar(12)   NOT NULL CHECK (product_type IN ('BOOK','CLOTHES','SHOES','ELECTRONICS','LAPTOP','MOBILE')),
    name           varchar(200)  NOT NULL,
    price          numeric(12,2) NOT NULL CHECK (price >= 0),
    stock_quantity integer       NOT NULL CHECK (stock_quantity >= 0),
    image_url      varchar(255)
);

-- Book
CREATE TABLE book (
    product_id varchar(20)  NOT NULL PRIMARY KEY REFERENCES product (product_id) ON DELETE CASCADE,
    author     varchar(120) NOT NULL,
    publisher  varchar(120) NOT NULL
);

-- Clothes
CREATE TABLE clothes (
    product_id varchar(20) NOT NULL PRIMARY KEY REFERENCES product (product_id) ON DELETE CASCADE,
    brand      varchar(60) NOT NULL,
    size       varchar(10) NOT NULL,
    color      varchar(30) NOT NULL,
    material   varchar(60) NOT NULL
);

-- Shoes
CREATE TABLE shoes (
    product_id varchar(20) NOT NULL PRIMARY KEY REFERENCES product (product_id) ON DELETE CASCADE,
    brand      varchar(60) NOT NULL,
    size       integer     NOT NULL CHECK (size > 0),
    color      varchar(30) NOT NULL
);

-- Electronics
CREATE TABLE electronics (
    product_id      varchar(20) NOT NULL PRIMARY KEY REFERENCES product (product_id) ON DELETE CASCADE,
    brand           varchar(60) NOT NULL,
    warranty_months integer     NOT NULL CHECK (warranty_months >= 0)
);

-- Laptop
CREATE TABLE laptop (
    product_id  varchar(20)  NOT NULL PRIMARY KEY REFERENCES electronics (product_id) ON DELETE CASCADE,
    cpu         varchar(60)  NOT NULL,
    ram         varchar(20)  NOT NULL,
    storage     varchar(30)  NOT NULL,
    screen_size numeric(4,1) NOT NULL
);

-- Mobile
CREATE TABLE mobile (
    product_id       varchar(20)  NOT NULL PRIMARY KEY REFERENCES electronics (product_id) ON DELETE CASCADE,
    os               varchar(30)  NOT NULL,
    camera           varchar(60)  NOT NULL,
    screen_size      numeric(4,1) NOT NULL,
    battery_capacity integer      NOT NULL CHECK (battery_capacity > 0)
);

-- VectorIndex (search)
CREATE TABLE product_feature (
    product_id     varchar(20) NOT NULL PRIMARY KEY REFERENCES product (product_id) ON DELETE CASCADE,
    model_version  varchar(40) NOT NULL,
    feature_vector bytea       NOT NULL,
    updated_at     timestamp   NOT NULL
);

-- Cart
CREATE TABLE cart (
    cart_id      varchar(20) NOT NULL PRIMARY KEY,
    customer_id  varchar(20) NOT NULL UNIQUE REFERENCES customer (customer_id),
    created_date timestamp   NOT NULL,
    updated_date timestamp   NOT NULL
);

-- CartItem
CREATE TABLE cart_item (
    cart_id    varchar(20)   NOT NULL REFERENCES cart (cart_id) ON DELETE CASCADE,
    product_id varchar(20)   NOT NULL REFERENCES product (product_id),
    quantity   integer       NOT NULL CHECK (quantity > 0),
    cart_price numeric(12,2) NOT NULL CHECK (cart_price >= 0),
    PRIMARY KEY (cart_id, product_id)
);

-- Order
CREATE TABLE orders (
    order_id     varchar(20)   NOT NULL PRIMARY KEY,
    customer_id  varchar(20)   NOT NULL REFERENCES customer (customer_id),
    order_date   timestamp     NOT NULL,
    status       varchar(12)   NOT NULL CHECK (status IN ('PLACED','PROCESSING','SHIPPED','DELIVERED','CANCELLED')),
    total_amount numeric(12,2) NOT NULL CHECK (total_amount >= 0)
);

-- OrderItem
CREATE TABLE order_item (
    order_id   varchar(20)   NOT NULL REFERENCES orders (order_id) ON DELETE CASCADE,
    product_id varchar(20)   NOT NULL REFERENCES product (product_id),
    quantity   integer       NOT NULL CHECK (quantity > 0),
    unit_price numeric(12,2) NOT NULL CHECK (unit_price >= 0),
    PRIMARY KEY (order_id, product_id)
);

-- Shipping
CREATE TABLE shipping (
    shipping_id     varchar(20)   NOT NULL PRIMARY KEY,
    order_id        varchar(20)   NOT NULL UNIQUE REFERENCES orders (order_id),
    address_id      varchar(20)   NOT NULL REFERENCES address (address_id),
    carrier         varchar(60),
    tracking_number varchar(40),
    shipping_fee    numeric(12,2) NOT NULL CHECK (shipping_fee >= 0),
    status          varchar(12)   NOT NULL CHECK (status IN ('PREPARING','IN_TRANSIT','DELIVERED')),
    delivered_date  date
);

-- Payment
CREATE TABLE payment (
    payment_id   varchar(20)   NOT NULL PRIMARY KEY,
    order_id     varchar(20)   NOT NULL REFERENCES orders (order_id),
    method       varchar(6)    NOT NULL CHECK (method IN ('CASH','CREDIT')),
    amount       numeric(12,2) NOT NULL CHECK (amount >= 0),
    payment_date timestamp,
    status       varchar(10)   NOT NULL CHECK (status IN ('PENDING','SUCCEEDED','FAILED'))
);

-- PayCash
CREATE TABLE pay_cash (
    payment_id    varchar(20)   NOT NULL PRIMARY KEY REFERENCES payment (payment_id) ON DELETE CASCADE,
    cash_received numeric(12,2),
    change_amount numeric(12,2)
);

-- PayCredit
CREATE TABLE pay_credit (
    payment_id         varchar(20)  NOT NULL PRIMARY KEY REFERENCES payment (payment_id) ON DELETE CASCADE,
    card_holder        varchar(100) NOT NULL,
    bank_name          varchar(60)  NOT NULL,
    card_last4         char(4)      NOT NULL,
    authorization_code varchar(40)
);
