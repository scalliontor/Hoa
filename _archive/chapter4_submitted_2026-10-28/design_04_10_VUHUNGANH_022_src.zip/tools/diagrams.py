"""Layout of the Chapter 4 diagrams; members and relationships come from model.py.

write_xml() produces vp/diagrams.xml for the TieuLuanBuilder VP plugin. Box sizes
are estimated from the member text: fitSize() collapses shapes when VP runs headless.
"""
import re
import xml.etree.ElementTree as ET

import model

PROJECT = "vp/tieuluan_design.vpp"
VIS = {"+": "public", "-": "private", "#": "protected", "~": "package"}

# Soft fills per business area / layer.
BLUE, GREEN, ORANGE, PURPLE, GREY, WHITE, YELLOW = (
    "#DCEBFA", "#E2F3DF", "#FDEBD3", "#ECE3F7", "#EFEFEF", "#FFFFFF", "#FFF4D2")
AREA = {
    "FullName": BLUE, "Customer": BLUE, "Address": BLUE, "CustomerVIP": BLUE, "CustomerNew": BLUE,
    "Cart": GREEN, "CartItem": GREEN, "Order": GREEN, "OrderItem": GREEN, "OrderStatus": GREY,
    "Shipping": ORANGE, "ShippingStatus": GREY, "Payment": ORANGE, "PayCash": ORANGE, "PayCredit": ORANGE,
    "PaymentStatus": GREY, "Product": PURPLE, "Book": PURPLE, "Clothes": PURPLE, "Shoes": PURPLE,
    "Electronics": PURPLE, "Laptop": PURPLE, "Mobile": PURPLE,
}


def _diagram(root, id_, name, kind, scope, scope_name, **extra):
    d = ET.SubElement(root, "diagram", id=id_, name=name, kind=kind, scope=scope, scopeName=scope_name,
                      font="13")
    for k, v in extra.items():
        d.set(k, str(v))
    return d


# Measured on VP exports at 13 px Arial: about 6 px per member character, 15 px per line.
CHAR_W, LINE_H = 6.1, 15


def _text_w(lines, bold_name=""):
    """Width that fits the longest member line or the (bold) class name."""
    widest = max([len(t) * CHAR_W for t in lines] + [len(bold_name) * 7.6, 60])
    return int(widest + 30)


def _class_size(name, attrs, ops, stereotype=None, literals=(), hide=False):
    """attrs/ops are display strings as VP renders them, e.g. '-cartId : String'."""
    head = 22 + (15 if stereotype else 0)
    if hide:
        return _text_w([f"<<{stereotype}>>"] if stereotype else [], name), head + 14
    body_a = 6 + LINE_H * len(attrs or literals)
    body_o = 6 + LINE_H * len(ops)
    lines = list(attrs) + list(ops) + list(literals) + ([f"<<{stereotype}>>"] if stereotype else [])
    return _text_w(lines, name), head + body_a + body_o + 6


def _node(d, nid, type_, name, x, y, w=160, h=80, **attrs):
    n = ET.SubElement(d, "node", id=nid, type=type_, name=name, x=str(x), y=str(y), w=str(w), h=str(h))
    for k, v in attrs.items():
        if v is not None and v is not False:
            n.set(k, "true" if v is True else str(v))
    return n


def _edge(d, type_, frm, to, points=None, **attrs):
    e = ET.SubElement(d, "edge", type=type_, **{"from": frm, "to": to})
    for k, v in attrs.items():
        if v is not None and v is not False:
            e.set(k, "true" if v is True else str(v))
    for x, y in points or ():
        ET.SubElement(e, "pt", x=str(x), y=str(y))
    return e


def _analysis_class(d, name, x, y, stereotype=None):
    shown = ["-" + t.replace(":", " :") for t in model.ANALYSIS[name]]
    w, h = _class_size(name, shown, [], stereotype)
    n = _node(d, name, "Class", name, x, y, w=w, h=h, fill=AREA[name], stereotype=stereotype,
              abstract=name in model.ANALYSIS_ABSTRACT)
    for text in model.ANALYSIS[name]:
        attr_name, attr_type = (s.strip() for s in text.split(":"))
        ET.SubElement(n, "attr", name=attr_name, type=attr_type)
    return n


def _design_class(d, name, x, y, parent=None, hide=False, fill=None):
    c = model.DESIGN_BY_NAME[name]
    stereotype = {"interface": "Interface", "enum": "enumeration"}.get(c["kind"])
    attrs = [f'{a["vis"]}{a["name"]} : {a["type"]}' for a in c["attrs"]]
    ops = [f'{o["vis"]}{o["name"]}(' + ", ".join(f"{p} : {t}" for p, t in o["params"]) + ")"
           + (f' : {o["ret"]}' if o["ret"] else "") for o in c["ops"]]
    w, h = _class_size(name, attrs, ops, stereotype, c["literals"], hide)
    n = _node(d, name, "Class", name, x, y, w=w, h=h, fill=fill or AREA.get(name, WHITE), stereotype=stereotype,
              abstract=c["abstract"], parent=parent, hideMembers=hide)
    for a in c["attrs"]:
        ET.SubElement(n, "attr", name=a["name"], type=a["type"], vis=VIS[a["vis"]])
    for lit in c["literals"]:
        ET.SubElement(n, "literal", name=lit)
    for o in c["ops"]:
        el = ET.SubElement(n, "op", name=o["name"], vis=VIS[o["vis"]],
                           params=", ".join(f"{p}: {t}" for p, t in o["params"]))
        if o["ret"]:
            el.set("ret", o["ret"])
        if o["static"]:
            el.set("static", "true")
        if o["abstract"] or c["kind"] == "interface":
            el.set("abstract", "true")
    return n


# ------------------------------------------------------------------ 4.1
ANALYSIS_POS = {
    "FullName": (40, 40), "Customer": (330, 190), "Address": (20, 430),
    "CustomerVIP": (240, 430), "CustomerNew": (460, 430),
    "Cart": (700, 40), "CartItem": (1000, 40), "Order": (700, 330), "OrderItem": (1000, 350),
    "Shipping": (420, 680), "Payment": (760, 660), "PayCash": (660, 920), "PayCredit": (900, 920),
    "Product": (1360, 170),
    "Book": (1180, 470), "Clothes": (1370, 470), "Shoes": (1560, 470), "Electronics": (1740, 470),
    "Laptop": (1650, 700), "Mobile": (1860, 700),
}


def analysis_diagram(root):
    d = _diagram(root, "c41_analysis", "4.1 Class Diagram in Analysis", "class", "analysis",
                 "4.1 Analysis model", route="orthogonal")
    for name, (x, y) in ANALYSIS_POS.items():
        _analysis_class(d, name, x, y)
    for a in model.ANALYSIS_ASSOCIATIONS:
        _edge(d, "Association", a["a"], a["b"], name=a["name"], fromMult=a["a_mult"], toMult=a["b_mult"],
              aggregation={"composition": "composite", "aggregation": "shared"}.get(a["kind"]))
    for child, parent in model.ANALYSIS_GENERALIZATIONS:
        _edge(d, "Generalization", child, parent)
    for client, supplier, stereotype, name in model.ANALYSIS_DEPENDENCIES:
        _edge(d, "Dependency", client, supplier, stereotype=stereotype, name=name)


# ------------------------------------------------------------------ 4.2
def orm_diagram(root):
    """Data model: every class persistable, generalizations become 1 -- 0..1 'is a' associations."""
    d = _diagram(root, "c42_orm", "4.2a Data Model (ORM-Persistable)", "class", "datamodel",
                 "4.2 Data model", route="orthogonal")
    for name, (x, y) in ANALYSIS_POS.items():
        _analysis_class(d, name, x, y + (0 if y < 300 else 30), stereotype="ORM-Persistable")
    for a in model.ANALYSIS_ASSOCIATIONS:
        _edge(d, "Association", a["a"], a["b"], name=a["name"], fromMult=a["a_mult"], toMult=a["b_mult"],
              aggregation={"composition": "composite", "aggregation": "shared"}.get(a["kind"]))
    for child, parent in model.ANALYSIS_GENERALIZATIONS:
        _edge(d, "Association", parent, child, name="is a", fromMult="1", toMult="0..1")


ERD_POS = {
    "customer_vip": (40, 40), "customer_new": (40, 260), "customer": (420, 40), "address": (420, 330),
    "cart": (820, 40), "orders": (820, 300), "shipping": (820, 560),
    "cart_item": (1240, 40), "order_item": (1240, 300), "payment": (1240, 580),
    "pay_cash": (900, 870), "pay_credit": (1260, 870),
    "product": (1660, 150), "product_feature": (1660, 470), "laptop": (1660, 720),
    "book": (2080, 40), "clothes": (2080, 190), "shoes": (2080, 400), "electronics": (2080, 590),
    "mobile": (2080, 790),
}


def erd_diagram(root):
    d = _diagram(root, "c42_erd", "4.2c Database (VP entity relationship diagram)", "erd", "database",
                 "4.2 Database")
    for t in model.TABLES:
        x, y = ERD_POS[t["name"]]
        texts = [c["name"] + "  " + c["type"] + (f'({c["length"]}' + (f',{c["scale"]}' if c["scale"] else "") + ")"
                                                 if c["length"] else "") for c in t["columns"]]
        n = _node(d, t["name"], "DBTable", t["name"], x, y, w=_text_w(texts, t["name"]) + 40,
                  h=34 + 19 * len(t["columns"]))
        for c in t["columns"]:
            el = ET.SubElement(n, "column", name=c["name"], type=c["type"])
            for key in ("length", "scale"):
                if c[key] is not None:
                    el.set(key, str(c[key]))
            for key in ("pk", "nullable", "unique"):
                if c[key]:
                    el.set(key, "true")
            if c["fk"]:
                el.set("fk", c["fk"])
    for child, column, parent, _ in model.foreign_keys():
        name, parent_mult, child_mult = model.FK_LABELS[f"{child}.{column}"]
        pk = next(c["pk"] for t in model.TABLES if t["name"] == child for c in t["columns"] if c["name"] == column)
        _edge(d, "DBForeignKey", parent, child, name=name, fromMult=parent_mult, toMult=child_mult,
              toColumn=column, identifying=pk)


def _sql_type(c):
    if c["length"] is None:
        return c["type"]
    return f'{c["type"]}({c["length"]}' + (f',{c["scale"]}' if c["scale"] is not None else "") + ")"


def _keys(c):
    keys = [k for k, on in (("PK", c["pk"]), ("FK", c["fk"]), ("U", c["unique"]), ("NULL", c["nullable"])) if on]
    return " {" + ", ".join(keys) + "}" if keys else ""


TABLE_POS = {name: (x, y) for name, (x, y) in ERD_POS.items()}


def tables_diagram(root):
    """Physical model drawn as <<table>> classes: VP renders these reliably when exporting headless."""
    d = _diagram(root, "c42_tables", "4.2b Database - tables, keys and foreign keys", "class", "tables",
                 "4.2 Database (tables)")
    for t in model.TABLES:
        x, y = TABLE_POS[t["name"]]
        shown = [f'+{c["name"]} : {_sql_type(c)}{_keys(c)}' for c in t["columns"]]
        w, h = _class_size(t["name"], shown, [], "table")
        n = _node(d, t["name"], "Class", t["name"], x, y, w=w, h=h, stereotype="table", fill=ORANGE,
                  hideOperations=True)
        for c in t["columns"]:
            ET.SubElement(n, "attr", name=c["name"], type=_sql_type(c) + _keys(c), vis="public")
    for child, column, parent, _ in model.foreign_keys():
        name, parent_mult, child_mult = model.FK_LABELS[f"{child}.{column}"]
        _edge(d, "Association", parent, child, name=f"{name} ({column})", fromMult=parent_mult,
              toMult=child_mult)


# ------------------------------------------------------------------ 4.3
DESIGN_POS = {
    "FullName": (40, 40), "Customer": (360, 250), "Address": (320, 600),
    "CustomerVIP": (20, 440), "CustomerNew": (20, 640),
    "Cart": (900, 40), "CartItem": (1430, 40), "OrderStatus": (1290, 240),
    "Order": (900, 360), "OrderItem": (1430, 400),
    "Shipping": (860, 760), "ShippingStatus": (1300, 800),
    "Payment": (1560, 720), "PaymentStatus": (1850, 740), "PayCash": (1440, 1000), "PayCredit": (1740, 1000),
    "Product": (2060, 40),
    "Book": (1980, 330), "Clothes": (2220, 330), "Shoes": (2460, 330), "Electronics": (2700, 330),
    "Laptop": (2580, 560), "Mobile": (2820, 560),
}


def design_diagram(root):
    d = _diagram(root, "c43_design", "4.3 Class Diagram in Design", "class", "design",
                 "4.3-4.5 Design model", route="orthogonal")
    for name, (x, y) in DESIGN_POS.items():
        _design_class(d, name, x, y)
    for a in model.DESIGN_ASSOCIATIONS:
        _edge(d, "Association", a["src"], a["dst"], name=a["name"], fromMult=a["src_mult"], toMult=a["mult"],
              toRole=a["role"], navigable=True,
              aggregation={"composition": "composite", "aggregation": "shared"}.get(a["kind"]))
    for c in model.DESIGN:
        if c["extends"] and c["name"] in DESIGN_POS:
            _edge(d, "Generalization", c["name"], c["extends"])
    for client, supplier, stereotype in model.DESIGN_DEPENDENCIES_43:
        _edge(d, "Dependency", client, supplier, stereotype=stereotype)


# ------------------------------------------------------------------ 4.4
LAYER_FILL = {"Presentation": YELLOW, "Application": GREEN, "Domain": BLUE, "Infrastructure": PURPLE}
SUBPACKAGE_ID = {pkg: "pkg_" + pkg.replace(".", "_") for _, _, subs in model.LAYERS for pkg in subs}


def _short(pkg):
    """'infrastructure.dao.jdbc' -> 'dao.jdbc'"""
    return pkg.split(".", 1)[1]


def layers_diagram(root):
    d = _diagram(root, "c44_layers", "4.4a Layers and Packages", "class", "design", "4.3-4.5 Design model")
    y = 40
    centers = {}
    for title, lid, subs in model.LAYERS:
        h = 150
        _node(d, "pkg_" + lid, "Package", f"{lid} ({title} layer)", 40, y, w=980, h=h, fill=LAYER_FILL[title])
        x = 70
        width = (920 - 20 * (len(subs) - 1)) // len(subs)
        for pkg in subs:
            _node(d, SUBPACKAGE_ID[pkg], "Package", _short(pkg), x, y + 45, w=width, h=85, fill=WHITE,
                  parent="pkg_" + lid)
            x += width + 20
        centers[title] = y
        y += h + 70
    top = centers
    # Straight dependencies between neighbouring layers; Application -> Infrastructure goes round Domain.
    _edge(d, "Dependency", "pkg_presentation", "pkg_application", stereotype="use",
          points=[(530, top["Presentation"] + 150), (530, top["Application"])])
    _edge(d, "Dependency", "pkg_application", "pkg_domain", stereotype="use",
          points=[(430, top["Application"] + 150), (430, top["Domain"])])
    _edge(d, "Dependency", "pkg_application", "pkg_infrastructure", stereotype="use",
          points=[(1020, top["Application"] + 75), (1080, top["Application"] + 75),
                  (1080, top["Infrastructure"] + 75), (1020, top["Infrastructure"] + 75)])
    _edge(d, "Dependency", "pkg_infrastructure", "pkg_domain", stereotype="use",
          points=[(630, top["Infrastructure"]), (630, top["Domain"] + 150)])
    for c in model.DESIGN:
        ET.SubElement(d, "contain", package=SUBPACKAGE_ID[c["package"]], **{"class": c["name"]})


# Positions of classes inside the layer/sub-package boxes of 4.4b.
LAYER_BOXES = {
    # id: (x, y, w, h)
    "pkg_presentation": (40, 40, 1300, 150),
    "pkg_presentation_controller": (60, 80, 1260, 95),
    "pkg_application": (40, 240, 1300, 330),
    "pkg_application_service": (60, 280, 800, 120),
    "pkg_application_search": (880, 280, 440, 270),
    "pkg_infrastructure": (40, 620, 1300, 330),
    "pkg_infrastructure_dao": (60, 660, 800, 120),
    "pkg_infrastructure_dao_jdbc": (60, 810, 800, 120),
    "pkg_infrastructure_search": (880, 660, 440, 270),
    "pkg_domain": (1400, 40, 1000, 910),
    "pkg_domain_customer": (1420, 80, 960, 170),
    "pkg_domain_product": (1420, 270, 960, 170),
    "pkg_domain_cart": (1420, 460, 300, 150),
    "pkg_domain_order": (1740, 460, 640, 150),
    "pkg_domain_payment": (1420, 630, 960, 150),
}
LAYER_CLASSES = {
    "pkg_presentation_controller": [("CartController", 90, 115), ("CheckoutController", 360, 115),
                                    ("OrderController", 680, 115), ("SearchController", 1010, 115)],
    "pkg_application_service": [("CartService", 100, 320), ("CheckoutService", 370, 320),
                                ("OrderService", 690, 320)],
    "pkg_application_search": [("SearchService", 1010, 320), ("QueryService", 900, 420),
                               ("RankingService", 1120, 420), ("CommonQuery", 900, 490),
                               ("SearchResult", 1120, 490)],
    "pkg_infrastructure_dao": [("CartDAO", 90, 700), ("ProductDAO", 290, 700), ("CustomerDAO", 480, 700),
                               ("OrderDAO", 690, 700)],
    "pkg_infrastructure_dao_jdbc": [("JdbcCartDAO", 80, 855), ("JdbcProductDAO", 270, 855),
                                    ("JdbcCustomerDAO", 460, 855), ("JdbcOrderDAO", 680, 855)],
    "pkg_infrastructure_search": [("VectorIndex", 1010, 720)],
    "pkg_domain_customer": [("Customer", 1450, 120), ("FullName", 1640, 120), ("Address", 1820, 120),
                            ("CustomerVIP", 1990, 120), ("CustomerNew", 2180, 120)],
    "pkg_domain_product": [("Product", 1450, 310), ("Book", 1610, 310), ("Clothes", 1750, 310),
                           ("Shoes", 1900, 310), ("Electronics", 2030, 310), ("Laptop", 2200, 310),
                           ("Mobile", 2200, 375)],
    "pkg_domain_cart": [("Cart", 1450, 500), ("CartItem", 1580, 500)],
    "pkg_domain_order": [("Order", 1770, 500), ("OrderItem", 1880, 500), ("Shipping", 2010, 500),
                         ("OrderStatus", 1880, 560), ("ShippingStatus", 2050, 560)],
    "pkg_domain_payment": [("Payment", 1450, 670), ("PayCash", 1600, 670), ("PayCredit", 1740, 670),
                           ("PaymentStatus", 1890, 670)],
}
# Service -> domain dependencies run along the gap between the Application and Infrastructure layers.
LAYER_ROUTES = {
    ("CartService", "Cart"): [(110, 356), (110, 600), (1480, 600), (1480, 536)],
    ("CheckoutService", "Order"): [(380, 356), (380, 585), (1804, 585), (1804, 536)],
}


def layer_classes_diagram(root):
    """Classes per layer. VP hides classes drawn over package shapes, so notes label the
    layers and Java packages here; package ownership is set in the 4.4a diagram."""
    d = _diagram(root, "c44_classes", "4.4b Classes and Relationships per Layer", "class", "design",
                 "4.3-4.5 Design model")
    layer_of = {"pkg_" + lid: title for title, lid, _ in model.LAYERS}
    for pid, (x, y, w, h) in LAYER_BOXES.items():
        if pid in layer_of:
            text = f"{layer_of[pid].upper()} LAYER"
        else:
            text = f"package {model.BASE_PACKAGE}.{next(p for p, i in SUBPACKAGE_ID.items() if i == pid)}"
        _node(d, "note_" + pid, "Note", text, x, y + (0 if pid in layer_of else 6),
              w=int(len(text) * (9.0 if pid in layer_of else 7.2) + 34), h=26,
              fill=LAYER_FILL.get(layer_of.get(pid), WHITE))
    for pid, members in LAYER_CLASSES.items():
        layer = next(l for l in layer_of if pid.startswith(l + "_"))
        for name, x, y in members:
            _design_class(d, name, x, y, hide=True, fill=AREA.get(name) or LAYER_FILL[layer_of[layer]])
    for client, supplier, stereotype in model.DESIGN_DEPENDENCIES_44:
        _edge(d, "Dependency", client, supplier, stereotype=stereotype,
              points=LAYER_ROUTES.get((client, supplier)))
    for c in model.DESIGN:
        for interface in c["implements"]:
            _edge(d, "Realization", c["name"], interface)


# Design sequence of CheckoutService.checkout (slide A05), lifelines typed by the 4.4 classes.
SEQ_LIFELINES = ["CheckoutController", "CheckoutService", "CartDAO", "CustomerDAO", "ProductDAO", "Order",
                 "OrderDAO"]
SEQ_MESSAGES = [  # (y, from, to, label, kind)
    (150, "Customer", "CheckoutController", "checkout(addressId, paymentMethod)", "call"),
    (190, "CheckoutController", "CheckoutService", "checkout(customerId, addressId, payment)", "call"),
    (230, "CheckoutService", "CartDAO", "findByCustomerId(customerId)", "call"),
    (262, "CartDAO", "CheckoutService", "cart", "return"),
    (300, "CheckoutService", "CustomerDAO", "findById(customerId)", "call"),
    (332, "CustomerDAO", "CheckoutService", "customer", "return"),
    (370, "CheckoutService", "Order", "<<create>> Order()", "call"),
    (440, "CheckoutService", "ProductDAO", "findById(productId)", "call"),
    (472, "ProductDAO", "CheckoutService", "current", "return"),
    (510, "CheckoutService", "Order", "addItem(OrderItem.fromCartItem(item, current))", "call"),
    (600, "CheckoutService", "Order", "calculateTotal(customer.getDiscountRate())", "call"),
    (640, "CheckoutService", "OrderDAO", "save(order)", "call"),
    (680, "CheckoutService", "ProductDAO", "decreaseStock(productId, quantity)", "call"),
    (720, "CheckoutService", "CartDAO", "clear(cartId)", "call"),
    (760, "CheckoutService", "CheckoutController", "order", "return"),
    (800, "CheckoutController", "Customer", "order (PLACED)", "return"),
]
SEQ_ACTIVATIONS = {"CheckoutController": [(150, 800)], "CheckoutService": [(190, 760)],
                   "CartDAO": [(230, 262), (720, 740)], "CustomerDAO": [(300, 332)],
                   "ProductDAO": [(440, 472), (680, 700)], "Order": [(370, 390), (510, 530), (600, 620)],
                   "OrderDAO": [(640, 660)]}


def sequence_diagram(root):
    d = _diagram(root, "c44_checkout_seq", "4.4c Checkout across the layers (design sequence)", "sequence",
                 "design", "4.3-4.5 Design model", numbers="true")
    center = {"Customer": 90}
    _node(d, "Customer", "SeqActor", "Customer", 70, 40, w=40, h=820)
    for i, name in enumerate(SEQ_LIFELINES):
        x = 180 + i * 200
        center[name] = x + 85
        _node(d, name, "Lifeline", "", x, 40, w=170, h=820, classifier=name)
    _node(d, "loop", "Fragment", "", 300, 405, w=1150, h=145, operator="loop",
          covers="CheckoutService,ProductDAO,Order")
    ET.SubElement(d.find("node[@id='loop']"), "operand", guard="for each item in cart.items", y="430", h="115")
    for y, frm, to, label, kind in SEQ_MESSAGES:
        _edge(d, "Message", frm, to, name=label, points=[(center[frm], y), (center[to], y)],
              **{"return": kind == "return"})
    for name, spans in SEQ_ACTIVATIONS.items():
        for y1, y2 in spans:
            ET.SubElement(d, "activation", on=name, y1=str(y1), y2=str(y2))


def write_xml(path):
    root = ET.Element("diagrams", project=PROJECT)
    analysis_diagram(root)
    orm_diagram(root)
    tables_diagram(root)
    erd_diagram(root)
    design_diagram(root)
    layer_classes_diagram(root)  # creates the remaining design classes ...
    layers_diagram(root)         # ... which 4.4a then places in their packages
    sequence_diagram(root)
    ET.indent(root)
    path.parent.mkdir(parents=True, exist_ok=True)
    ET.ElementTree(root).write(path, encoding="utf-8", xml_declaration=True)
    return [dict(id=d.get("id"), name=d.get("name")) for d in root.findall("diagram")]


if __name__ == "__main__":
    from pathlib import Path
    for d in write_xml(Path(__file__).resolve().parents[1] / "vp/diagrams.xml"):
        print(d["id"], "-", d["name"])
