"""Generate the Java skeleton of section 4.5 from the 4.4 design model.

Usage: python3 tools/gen_java.py
Writes code/src/com/ptit/ecom/**, build/code_tree.txt and build/excerpts/*.java.
"""
from pathlib import Path
import re
import shutil
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tools"))
import model  # noqa: E402

SRC = ROOT / "code" / "src"
BUILD = ROOT / "build"
VIS = {"+": "public", "-": "private", "#": "protected", "~": ""}
JDK = {
    "BigDecimal": "java.math.BigDecimal",
    "LocalDate": "java.time.LocalDate",
    "LocalDateTime": "java.time.LocalDateTime",
    "List": "java.util.List",
    "ArrayList": "java.util.ArrayList",
    "Map": "java.util.Map",
    "DataSource": "javax.sql.DataSource",
    "Connection": "java.sql.Connection",
    "PreparedStatement": "java.sql.PreparedStatement",
    "ResultSet": "java.sql.ResultSet",
    "SQLException": "java.sql.SQLException",
}
HEADER = "Generated from the Chapter 4.4 design model (tools/model.py)."
_STRING = re.compile(r'"(?:\\.|[^"\\])*"')
_COMMENT = re.compile(r"//[^\n]*")
_TOKEN = re.compile(r"\b[A-Z][A-Za-z0-9_]*\b")


def many(mult):
    return mult.split("..")[-1] == "*"


def fields_of(c):
    """Attributes followed by association ends navigable from this class."""
    result = [(a["name"], a["type"], False) for a in c["attrs"]]
    for a in model.DESIGN_ASSOCIATIONS:
        if a["src"] == c["name"]:
            if many(a["mult"]):
                result.append((a["role"], f"List<{a['dst']}>", True))
            else:
                result.append((a["role"], a["dst"], False))
    return result


def ancestors(c):
    """Superclass chain and implemented interfaces, nearest first."""
    seen, todo = [], [c]
    while todo:
        cur = todo.pop(0)
        parents = ([cur["extends"]] if cur["extends"] else []) + cur["implements"]
        for p in parents:
            parent = model.DESIGN_BY_NAME.get(p)
            if parent and parent not in seen:
                seen.append(parent)
                todo.append(parent)
    return seen


def signature_key(o):
    return o["name"], tuple(t for _, t in o["params"])


def overrides(c, o):
    key = signature_key(o)
    return any(signature_key(p) == key for a in ancestors(c) for p in a["ops"] if p["name"] != a["name"])


def imports_for(c, field_list):
    text = " ".join(t for _, t, _ in field_list)
    for o in c["ops"]:
        text += " " + " ".join(t for _, t in o["params"]) + " " + (o["ret"] or "")
        if o["body"]:
            text += " " + _COMMENT.sub("", _STRING.sub('""', o["body"]))
    text += " " + " ".join(filter(None, [c["extends"]] + c["implements"]))
    if any(is_list for _, _, is_list in field_list):
        text += " ArrayList"
    result = set()
    for token in set(_TOKEN.findall(text)):
        if token in JDK:
            result.add(JDK[token])
        elif token in model.DESIGN_BY_NAME and token != c["name"]:
            other = model.DESIGN_BY_NAME[token]
            if other["package"] != c["package"]:
                result.add(f"{model.BASE_PACKAGE}.{other['package']}.{token}")
    return sorted(result)


def javadoc(c):
    if c["doc"]:
        return f"/**\n * {HEADER}\n * {c['doc']}\n */"
    return f"/** {HEADER} */"


def params(o):
    return ", ".join(f"{t} {n}" for n, t in o["params"])


def body_lines(body, indent):
    lines = body.strip("\n").splitlines()
    return [(" " * indent + line) if line.strip() else "" for line in lines]


def method(c, o, interface=False):
    out = []
    is_ctor = o["name"] == c["name"]
    if interface:
        return [f"    {o['ret']} {o['name']}({params(o)});"]
    if not is_ctor and overrides(c, o):
        out.append("    @Override")
    mods = [VIS[o["vis"]]]
    if o["abstract"]:
        mods.append("abstract")
    if o["static"]:
        mods.append("static")
    mods = " ".join(m for m in mods if m)
    head = f"{mods} {o['name']}({params(o)})" if is_ctor else f"{mods} {o['ret']} {o['name']}({params(o)})"
    if o["abstract"]:
        return out + [f"    {head};"]
    out.append(f"    {head} {{")
    if o["body"]:
        out += body_lines(o["body"], 8)
    else:
        out.append(f'        throw new UnsupportedOperationException("TODO: {o["name"]}");')
    out.append("    }")
    return out


def wants_accessors(c):
    return c["package"].startswith("domain.") or c["name"] in {"CommonQuery", "SearchResult"}


def accessors(c, field_list):
    taken = {o["name"] for o in c["ops"]}
    blocks = []
    for name, type_, is_list in field_list:
        cap = name[0].upper() + name[1:]
        if f"get{cap}" not in taken:
            blocks.append([f"    public {type_} get{cap}() {{", f"        return {name};", "    }"])
        if not is_list and f"set{cap}" not in taken:
            blocks.append([f"    public void set{cap}({type_} {name}) {{", f"        this.{name} = {name};", "    }"])
    return blocks


def render(c):
    pkg = f"{model.BASE_PACKAGE}.{c['package']}"
    out = [f"package {pkg};", ""]
    if c["kind"] == "enum":
        out += [javadoc(c), f"public enum {c['name']} {{", "    " + ", ".join(c["literals"]), "}"]
        return "\n".join(out) + "\n"
    field_list = fields_of(c)
    imports = imports_for(c, field_list)
    if imports:
        out += [f"import {i};" for i in imports] + [""]
    out.append(javadoc(c))
    if c["kind"] == "interface":
        out.append(f"public interface {c['name']} {{")
        blocks = [method(c, o, interface=True) for o in c["ops"]]
    else:
        head = "public abstract class" if c["abstract"] else "public class"
        decl = f"{head} {c['name']}"
        if c["extends"]:
            decl += f" extends {c['extends']}"
        if c["implements"]:
            decl += " implements " + ", ".join(c["implements"])
        out.append(decl + " {")
        blocks = []
        if field_list:
            blocks.append([f"    private {t} {n}" + (" = new ArrayList<>();" if is_list else ";")
                           for n, t, is_list in field_list])
        ctors = [o for o in c["ops"] if o["name"] == c["name"]]
        if ctors and c["package"].startswith("domain.") and not any(not o["params"] for o in ctors):
            blocks.append([f"    public {c['name']}() {{", "    }"])
        blocks += [method(c, o) for o in ctors]
        blocks += [method(c, o) for o in c["ops"] if o["name"] != c["name"]]
        if wants_accessors(c):
            blocks += accessors(c, field_list)
    for i, block in enumerate(blocks):
        if i:
            out.append("")
        out += block
    out.append("}")
    return "\n".join(out) + "\n"


def path_of(c):
    return SRC / Path(*model.BASE_PACKAGE.split(".")) / Path(*c["package"].split(".")) / f"{c['name']}.java"


# -------------------------------------------------------------- excerpts

def block(text, start):
    """Lines of the member whose declaration line contains `start`, through its closing brace."""
    lines = text.splitlines()
    i = next(n for n, line in enumerate(lines) if start in line)
    while i > 0 and lines[i - 1].strip().startswith("@"):
        i -= 1
    if lines[i].rstrip().endswith(";"):
        return [lines[i]]
    depth, out = 0, []
    for line in lines[i:]:
        out.append(line)
        depth += line.count("{") - line.count("}")
        if depth == 0 and "{" in "".join(out):
            break
    return out


def header_and_fields(text):
    lines = text.splitlines()
    start = next(n for n, line in enumerate(lines) if line.startswith("public "))
    out = [lines[start]]
    for line in lines[start + 1:]:
        if not line.strip().startswith("private ") or "(" in line:
            break
        out.append(line)
    return out


def write_excerpts(sources):
    out_dir = BUILD / "excerpts"
    shutil.rmtree(out_dir, ignore_errors=True)
    out_dir.mkdir(parents=True)
    s = sources
    omitted = "    // ... other members and generated accessors omitted"
    excerpts = {
        "cart.java": header_and_fields(s["Cart"]) + [""]
        + block(s["Cart"], "public void addItem(") + [""]
        + block(s["Cart"], "public BigDecimal calculateTotal(") + [omitted, "}"],
        "orderitem.java": header_and_fields(s["OrderItem"]) + [""]
        + block(s["OrderItem"], "public static OrderItem fromCartItem(") + [""]
        + block(s["OrderItem"], "public BigDecimal getSubtotal(") + [omitted, "}"],
        "checkout.java": header_and_fields(s["CheckoutService"])
        + ["    // ... constructor injecting the four DAOs omitted", ""]
        + block(s["CheckoutService"], "public Order checkout(") + ["}"],
        "orderdao.java": [l for l in s["OrderDAO"].splitlines() if l.startswith(("public interface", "    ", "}"))]
        + [""] + [s["JdbcOrderDAO"].splitlines()[next(n for n, l in enumerate(s["JdbcOrderDAO"].splitlines())
                                                      if l.startswith("public class"))]]
        + ["    // ... constructor and other methods omitted", ""]
        + block(s["JdbcOrderDAO"], "public Order findByIdAndCustomer(") + ["}"],
        "payment.java": header_and_fields(s["Payment"]) + [""]
        + block(s["Payment"], "public abstract boolean process(") + [omitted, "}", ""]
        + header_and_fields(s["PayCash"]) + [""]
        + block(s["PayCash"], "public boolean process(") + [omitted, "}"],
        "search.java": ["public class SearchService {", "    // ... fields, constructor, searchText and searchVoice omitted", ""]
        + block(s["SearchService"], "public List<SearchResult> searchImage(") + ["}", ""]
        + ["public class SearchController {", "    // ... field and constructor omitted", ""]
        + block(s["SearchController"], "public List<SearchResult> search(") + ["}"],
    }
    for name, lines in excerpts.items():
        text = "\n".join(lines).rstrip() + "\n"
        n = text.count("\n")
        if n > 45:
            raise SystemExit(f"Excerpt {name} has {n} lines (> 45)")
        (out_dir / name).write_text(text)


def write_tree():
    base = SRC / Path(*model.BASE_PACKAGE.split("."))
    lines = [model.BASE_PACKAGE.replace(".", "/") + "/"]

    def walk(folder, prefix):
        entries = sorted([p for p in folder.iterdir() if p.is_dir()]) + \
            sorted([p for p in folder.iterdir() if p.suffix == ".java"])
        for i, p in enumerate(entries):
            last = i == len(entries) - 1
            lines.append(prefix + ("└── " if last else "├── ") + p.name + ("/" if p.is_dir() else ""))
            if p.is_dir():
                walk(p, prefix + ("    " if last else "│   "))

    walk(base, "")
    (BUILD / "code_tree.txt").write_text("\n".join(lines) + "\n")


def main():
    shutil.rmtree(SRC, ignore_errors=True)
    BUILD.mkdir(exist_ok=True)
    sources = {}
    for c in model.DESIGN:
        text = render(c)
        target = path_of(c)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(text)
        sources[c["name"]] = text
    write_tree()
    write_excerpts(sources)
    print(f"Generated {len(sources)} Java files in {SRC.relative_to(ROOT)}")


if __name__ == "__main__":
    main()
