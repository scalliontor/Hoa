"""Generate the PostgreSQL schema of section 4.2 and validate it in SQLite.

Usage: python3 tools/gen_sql.py
Writes db/ecom_schema.sql, build/sql_validation.txt, build/excerpts/schema.sql
and build/code_stats.tex.
"""
from pathlib import Path
import sqlite3
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tools"))
import model  # noqa: E402

DB = ROOT / "db"
BUILD = ROOT / "build"
SCHEMA = DB / "ecom_schema.sql"
# Composition parts and inheritance sub-tables disappear with their owner row.
CASCADE = {"cart_item.cart_id", "order_item.order_id", "customer_vip.customer_id", "customer_new.customer_id",
           "book.product_id", "clothes.product_id", "shoes.product_id", "electronics.product_id",
           "laptop.product_id", "mobile.product_id", "pay_cash.payment_id", "pay_credit.payment_id",
           "product_feature.product_id"}
POSTGRES_TYPE = {"blob": "bytea"}


def sql_type(c):
    name = POSTGRES_TYPE.get(c["type"], c["type"])
    if c["length"] is not None and c["scale"] is not None:
        return f"{name}({c['length']},{c['scale']})"
    if c["length"] is not None:
        return f"{name}({c['length']})"
    return name


def ordered_tables():
    """Tables with every referenced table first (stable topological order)."""
    by_name = {t["name"]: t for t in model.TABLES}
    done, result = set(), []

    def visit(name):
        if name in done:
            return
        done.add(name)
        for c in by_name[name]["columns"]:
            if c["fk"] and c["fk"].split(".")[0] != name:
                visit(c["fk"].split(".")[0])
        result.append(by_name[name])

    for t in model.TABLES:
        visit(t["name"])
    return result


def create_table(t):
    keys = [c for c in t["columns"] if c["pk"]]
    width = max(len(c["name"]) for c in t["columns"])
    type_width = max(len(sql_type(c)) for c in t["columns"])
    lines = []
    for c in t["columns"]:
        parts = [c["name"].ljust(width), sql_type(c).ljust(type_width)]
        if not c["nullable"]:
            parts.append("NOT NULL")
        if c["pk"] and len(keys) == 1:
            parts.append("PRIMARY KEY")
        if c["unique"]:
            parts.append("UNIQUE")
        if c["check"]:
            parts.append(f"CHECK ({c['check']})")
        if c["fk"]:
            parent, parent_col = c["fk"].split(".")
            parts.append(f"REFERENCES {parent} ({parent_col})")
            if f"{t['name']}.{c['name']}" in CASCADE:
                parts.append("ON DELETE CASCADE")
        lines.append("    " + " ".join(parts).rstrip())
    if len(keys) > 1:
        lines.append(f"    PRIMARY KEY ({', '.join(c['name'] for c in keys)})")
    body = ",\n".join(lines)
    return f"-- {t['source']}\nCREATE TABLE {t['name']} (\n{body}\n);"


def schema():
    tables = ordered_tables()
    head = [
        "-- E-commerce database generated from the Chapter 4.2 data model (tools/model.py).",
        "-- Target: PostgreSQL. Inheritance uses one table per class: a sub-table shares the",
        "-- primary key of its parent table and references it (class table inheritance).",
        "",
    ]
    head += [f"DROP TABLE IF EXISTS {t['name']};" for t in reversed(tables)]
    return "\n".join(head) + "\n\n" + "\n\n".join(create_table(t) for t in tables) + "\n"


SAMPLE = [
    ("customer", "INSERT INTO customer VALUES ('C001', 'Anh', 'Hùng', 'Vũ', 'anh@example.com', '0900000000', '2005-03-01')"),
    ("customer_vip", "INSERT INTO customer_vip VALUES ('C001', 2, 0.100, 1200)"),
    ("address", "INSERT INTO address VALUES ('A001', 'C001', '96A', 'Trần Phú', 'Hà Đông', 'Hà Nội')"),
    ("product", "INSERT INTO product VALUES ('P001', 'BOOK', 'Clean Code', 150000, 10, NULL)"),
    ("book", "INSERT INTO book VALUES ('P001', 'Robert C. Martin', 'Prentice Hall')"),
    ("product", "INSERT INTO product VALUES ('P002', 'LAPTOP', 'ThinkPad X1', 30000000, 2, NULL)"),
    ("electronics", "INSERT INTO electronics VALUES ('P002', 'Lenovo', 24)"),
    ("laptop", "INSERT INTO laptop VALUES ('P002', 'Core Ultra 7', '32GB', '1TB SSD', 14.0)"),
    ("cart", "INSERT INTO cart VALUES ('CART01', 'C001', '2026-10-28 20:00:00', '2026-10-28 20:05:00')"),
    ("cart_item", "INSERT INTO cart_item VALUES ('CART01', 'P001', 2, 150000)"),
    ("cart_item", "INSERT INTO cart_item VALUES ('CART01', 'P002', 1, 30000000)"),
    ("orders", "INSERT INTO orders VALUES ('O001', 'C001', '2026-10-28 20:10:00', 'PLACED', 27300000)"),
    ("order_item", "INSERT INTO order_item VALUES ('O001', 'P001', 2, 150000)"),
    ("order_item", "INSERT INTO order_item VALUES ('O001', 'P002', 1, 30000000)"),
    ("shipping", "INSERT INTO shipping VALUES ('S001', 'O001', 'A001', 'GHN', NULL, 30000, 'PREPARING', NULL)"),
    ("payment", "INSERT INTO payment VALUES ('PAY01', 'O001', 'CASH', 27300000, NULL, 'PENDING')"),
    ("pay_cash", "INSERT INTO pay_cash VALUES ('PAY01', NULL, NULL)"),
]
NEGATIVE = [
    ("cart_item quantity 0 violates CHECK (quantity > 0)",
     "UPDATE cart_item SET quantity = 0 WHERE cart_id = 'CART01' AND product_id = 'P001'", "CHECK"),
    ("order_item for unknown product P999 violates FOREIGN KEY",
     "INSERT INTO order_item VALUES ('O001', 'P999', 1, 1000)", "FOREIGN KEY"),
    ("second cart for C001 violates UNIQUE (cart.customer_id), multiplicity 1 : 0..1",
     "INSERT INTO cart VALUES ('CART02', 'C001', '2026-10-28 21:00:00', '2026-10-28 21:00:00')", "UNIQUE"),
]


def validate(ddl):
    log = [f"Validation of db/ecom_schema.sql with SQLite {sqlite3.sqlite_version} (:memory:, PRAGMA foreign_keys=ON)", ""]
    con = sqlite3.connect(":memory:")
    con.execute("PRAGMA foreign_keys = ON")
    con.executescript(ddl)
    tables = [r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name")]
    log.append(f"1. DDL executed: {len(tables)} tables created ({', '.join(tables)})")
    for table, statement in SAMPLE:
        con.execute(statement)
    con.commit()
    log.append(f"2. Sample data: {len(SAMPLE)} rows inserted into {len({t for t, _ in SAMPLE})} tables without error")
    rejected = 0
    log.append("3. Negative tests (each statement must be rejected):")
    for label, statement, expected in NEGATIVE:
        try:
            con.execute(statement)
            con.rollback()
            log.append(f"   FAIL accepted: {label}")
        except sqlite3.IntegrityError as error:
            ok = expected in str(error).upper()
            rejected += ok
            log.append(f"   {'PASS' if ok else 'FAIL'} {label}: {error}")
    total = con.execute("SELECT (SELECT SUM(quantity * unit_price) FROM order_item WHERE order_id = 'O001')").fetchone()[0]
    log.append(f"4. Order O001 subtotal from order_item snapshot prices: {total:,.0f}")
    con.execute("DELETE FROM cart WHERE cart_id = 'CART01'")
    left = con.execute("SELECT COUNT(*) FROM cart_item WHERE cart_id = 'CART01'").fetchone()[0]
    log.append(f"5. Deleting cart CART01 cascades to its cart_item rows: {left} rows left")
    log.append("")
    summary = (f"Result: {len(tables)} tables created; {len(SAMPLE)} rows inserted; "
               f"{rejected}/{len(NEGATIVE)} violations rejected; cascade delete OK" if left == 0 else "cascade FAILED")
    log.append(summary)
    if len(tables) != len(model.TABLES) or rejected != len(NEGATIVE) or left != 0:
        (BUILD / "sql_validation.txt").write_text("\n".join(log) + "\n")
        raise SystemExit("SQL validation failed:\n" + "\n".join(log))
    return log


def excerpt(ddl):
    blocks = ddl.split("\n\n")
    wanted = {"product", "cart_item", "orders", "order_item"}
    keep = [b for b in blocks if any(f"CREATE TABLE {w} (" in b for w in wanted)]
    text = "\n\n".join(keep) + "\n"
    if text.count("\n") > 45:
        raise SystemExit(f"schema.sql excerpt has {text.count(chr(10))} lines (> 45)")
    (BUILD / "excerpts").mkdir(parents=True, exist_ok=True)
    (BUILD / "excerpts" / "schema.sql").write_text(text)


def stats(ddl):
    base = ROOT / "code" / "src"
    files = sorted(base.rglob("*.java"))
    lines = sum(f.read_text().count("\n") for f in files)
    packages = {f.parent for f in files}
    text = "\n".join([
        f"\\newcommand{{\\javaFileCount}}{{{len(files)}}}",
        f"\\newcommand{{\\javaLineCount}}{{{lines}}}",
        f"\\newcommand{{\\javaPackageCount}}{{{len(packages)}}}",
        f"\\newcommand{{\\sqlTableCount}}{{{len(model.TABLES)}}}",
        f"\\newcommand{{\\sqlLineCount}}{{{ddl.count(chr(10))}}}",
    ])
    (BUILD / "code_stats.tex").write_text(text + "\n")


def main():
    DB.mkdir(exist_ok=True)
    BUILD.mkdir(exist_ok=True)
    ddl = schema()
    SCHEMA.write_text(ddl)
    log = validate(ddl)
    (BUILD / "sql_validation.txt").write_text("\n".join(log) + "\n")
    excerpt(ddl)
    stats(ddl)
    print(log[-1])


if __name__ == "__main__":
    main()
